<template>
  <div class="home"> home </div>
</template>

<script setup></script>
<style lang="scss">
  .home {
    color: $primary;
  }
</style>
