<template>
  <layout-content></layout-content>
</template>
<script setup>
  import LayoutContent from '../page/index.vue'
</script>
