export default {
  title: state => state.app.appTitle
}
