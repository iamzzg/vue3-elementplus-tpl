import '@/assets/icons/index' //图标
import 'windicss'
import 'normalize.css'
import '@/design/index.scss'
import resgisterGlobalComp from '@/components/resgisterGlobalComp'

export default app => {
  resgisterGlobalComp(app)
}
