/* eslint-disable */

// 微应用配置
if(window.__POWER_BY_QIANKUN){
  __webpack_public_path = window.__INJECTED_PUBLIC_PATH_BY_QIANKUN__
}
