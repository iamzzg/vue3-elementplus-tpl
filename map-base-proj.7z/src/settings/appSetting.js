export default {
  zIndex: 3000,
  size: 'small'
}
