export const LAYOUT = () => import('@/layout/default/index.vue')
